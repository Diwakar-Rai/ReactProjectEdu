import Bootcamp from 'bootcamp/Bootcamp'
import React from 'react'

const AddCourses = () => {
  return (
    <div>
      Add courses
      <Bootcamp/>
    </div>
  )
}

export default AddCourses
